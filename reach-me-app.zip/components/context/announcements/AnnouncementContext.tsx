import { createContext } from "react";

const AnnouncementContext = createContext<any>("");

export default AnnouncementContext;

export default function Friend(): any {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16.151" height="16">
      <g transform="translate(-1148 -632)">
        <ellipse
          cx="3"
          cy="3.5"
          rx="3"
          ry="3.5"
          transform="translate(1152 632)"
          fill="#1d1f23"
        />
        <path
          d="M1153.333 640h3.334a5.333 5.333 0 015.333 5.333 2.667 2.667 0 01-2.667 2.667h-8.666a2.667 2.667 0 01-2.667-2.667 5.333 5.333 0 015.333-5.333z"
          fill="#1d1f23"
        />
        <path
          d="M1159 636.506l1.528 1.528 2.92-2.92"
          fill="none"
          stroke="#1d1f23"
          strokeLinecap="square"
        />
      </g>
    </svg>
  );
}

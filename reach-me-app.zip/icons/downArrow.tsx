export default function DownArrow(): any {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="9">
      <path
        d="M9.121 7.739a1.5 1.5 0 01-2.242 0L2.219 2.5A1.5 1.5 0 013.34 0h9.32a1.5 1.5 0 011.121 2.5z"
        fill="#606770"
      />
    </svg>
  );
}

export default function More(): any {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="13" height="3">
      <g transform="translate(-1205 -635)" fill="#1d1f23">
        <circle cx="1.5" cy="1.5" r="1.5" transform="translate(1205 635)" />
        <circle cx="1.5" cy="1.5" r="1.5" transform="translate(1210 635)" />
        <circle cx="1.5" cy="1.5" r="1.5" transform="translate(1215 635)" />
      </g>
    </svg>
  );
}
